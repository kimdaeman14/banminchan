//
//  ProductViewCell.swift
//  collectiontest
//
//  Created by kimdaeman14 on 2018. 8. 8..
//  Copyright © 2018년 GoldenShoe. All rights reserved.
//

import UIKit

class ProductViewCell: UITableViewCell {

    
    static let reusableIdentifier = "productViewCell"

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

 
    
}
