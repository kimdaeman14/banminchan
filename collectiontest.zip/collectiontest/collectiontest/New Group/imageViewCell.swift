//
//  imageViewCell.swift
//  collectiontest
//
//  Created by kimdaeman14 on 2018. 8. 8..
//  Copyright © 2018년 GoldenShoe. All rights reserved.
//

import UIKit

class imageViewCell: UITableViewCell {

    static let reusableIdentifier = "imageviewcell"
    
    @IBOutlet weak var scrollView:UIScrollView!
    @IBOutlet weak var imageview:UIImageView!

    
    

    


    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

   
    
}
